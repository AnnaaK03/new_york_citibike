# Citi Bike NYC 2015: when and where people ride

## Overview
I analysed nearly 10 million Citi Bike trips from 2015 (New York) in BigQuery and built a Power BI dashboard on top of the results.
The goal is to understand how demand changes over time, how two types of riders behave, and which stations have a permanent imbalance of bikes.

## Business Value & Insights
Bike sharing has one daily operational problem: bikes pile up at some stations and run out at others. An empty station is a lost trip. A full station means a rider cannot return the bike.

- **Two demand patterns.** On weekdays there are two peaks: around 8:00 and 17:00–18:00 (commute). On weekends the busiest hour moves to the middle of the day (Saturday 13:00, Sunday 15:00), and it is about 35–40% lower than a weekday peak.
- **Stations mirror themselves.** The correlation between the morning and the evening net flow of a station is −0.93. A station that gains bikes in the morning loses them in the evening, and the other way round.
- **Offices fill up, homes and train stations empty.** In the morning bikes accumulate in Midtown and the Financial District (for example W 52 St & 5 Ave, +11.6k over the year). They leave from East Village and from transit hubs next to Penn Station and Port Authority (8 Ave & W 31 St, −35k, about 135 bikes per weekday morning). In the evening it reverses.
- **What it could be used for.** Planning bike redistribution before the morning and evening peaks, and choosing which stations to prioritise.
- **Seasonality:** [TBD after query 04: peak month, lowest month]
- **Rider types:** [TBD after query 06: share of Subscribers, median duration and weekend share by type]
- **Top routes:** [TBD after query 07]

**Limits of this analysis.** There is no data on station capacity or on how bikes were moved by the operator in 2015, so I measure imbalance, not the number of empty or full stations. Stations that lose bikes in both peaks (for example Pershing Square North and South near Grand Central) probably get bikes from outside the peaks, but this data cannot confirm it. It is one year of data, so the project describes a pattern and does not forecast.

## Technical Stack
- **Google BigQuery (SQL):** CTEs, window functions (`DENSE_RANK`, `ROW_NUMBER`, `QUALIFY`), `JOIN ... USING`, `APPROX_QUANTILES`, date functions
- **Power BI:** Import mode, DAX measures, interactive dashboard
- **GitHub:** SQL scripts in run order

## Data
Public NYC Citi Bike trips dataset (`new_york_citibike.citibike_trips`), copied into my own BigQuery project. Columns used: trip start and end time, duration, start and end station (name, id, coordinates), user type, birth year.
2015 was chosen because 2018 data is incomplete for several months.

## Data Cleaning
Short version: I excluded only one thing and documented everything else.

| Issue | Decision |
|---|---|
| 2,575 trips longer than 24 hours (the longest is about 68 days) | Excluded. This is a working rule for the project, not proof that each of these trips is an error |
| `birth_year` is empty for about 13% of trips | Kept. [TBD after check 3.2: whether these are all Customer trips] |
| Birth years before 1900 (1,016 trips) | Kept, not used in the analysis |
| `stoptime` earlier than `starttime` (70 trips) and duration mismatches | Not corrected. `DATETIME` has no time zone, so trips that cross a daylight-saving change look one hour off. Only a small part of all mismatches is explained by this, the rest is not classified yet. I use `tripduration` as the duration |
| Date filter | `BETWEEN` on a `DATETIME` cuts off the last day. Fixed with `>= '2015-01-01' AND < '2016-01-01'` |
| Valet and depot stations | Excluded from the station net flow analysis because they are service points |

## Repository
```
sql/
  01_check_date_range.sql        date range and the 31 December check
  02_create_clean_trips_2015.sql clean table
  03_data_quality_checks.sql     nulls, birth year, time consistency
  04_monthly_trend.sql           trips by month
  05_peak_hours.sql              weekday and weekend patterns
  06_user_segments.sql           Subscriber vs Customer
  07_routes_and_stations.sql     top routes and stations
  08_station_net_flow.sql        net flow per station (table for the map)
```
Run the files in this order.

## Dashboard
[Power BI link — TBD]

## Preview
![Dashboard preview](images/dashboard_preview.png)

## Next steps
- Forecast daily demand with BigQuery ML (ARIMA_PLUS), trained on several years
- Add weather data and check how much it explains demand
- Use real-time station availability data to measure how often stations are actually empty
